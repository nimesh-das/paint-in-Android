#include <iostream>
#include "collectosap.h"
using namespace std;

CollectOsap::CollectOsap(): Unownable() { }

CollectOsap::CollectOsap(string cellName, int indexOfProperty, Board *leboard): Unownable(cellName, indexOfProperty, leboard) { 
     
}

//Coop::~Coop() { }

void CollectOsap::QueryPlayer(Player *p) {
      // if (p->getx()
}
     

